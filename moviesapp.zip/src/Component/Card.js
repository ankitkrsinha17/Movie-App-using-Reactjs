import React from 'react'
import './style.css';

export default function Card({value}) {
    console.log("CARD",value);
    //HTML
    const IMGPATH = "https://image.tmdb.org/t/p/w1280";
    return (
        <div className="card">
            <img src={IMGPATH+value.poster_path} alt="Avatar"  />
            <div className='container-card'>
                <h4><b>{value.title}</b></h4>
                <p>{value.vote_average}</p>
                <p>{value.overview}</p>

            </div>
        </div>

    )
}
