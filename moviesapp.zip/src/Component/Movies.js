import React from 'react'
import Card from './Card'
import './style.css'

import { useState,useEffect } from 'react';
import axios from 'axios'
const APIURL = "https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=04c35731a5ee918f014970082a0088b1&page=1";
const SEARCHAPI = "https://api.themoviedb.org/3/search/movie?&api_key=04c35731a5ee918f014970082a0088b1&query=";
export default function () {
    // reactJS
    const [movies, setMovies] = useState([]);
    const [search, setSearch] = useState("");
  
    const changeTheSearch = (event) => {
      // console.log(event.target.value);
      setSearch(event.target.value);
    }
  
    const getAllMovies = () => {
      axios.get(APIURL)
        .then(
          (response) => {
            console.log(response.data.results)
            setMovies(response.data.results);
          }
        )
        .catch(
          (error) => {
            console.log(error)
          }
        )
    }
  
    const getSearchedMovies = () => {
      // console.log(SEARCHAPI + search)
      axios.get(
        SEARCHAPI + search
      )
        .then(
          (response) => {
            console.log(response.data.results)
            setMovies(response.data.results);
          }
        )
        .catch(
          (error) => { 
            console.log(error);
          }
        )
    }
  
    useEffect(
      () => {
        setMovies([]);
        // console.log("Hello");
        if (search === "") {
          getAllMovies();
        } else {
          getSearchedMovies();
        }
      },
      [search]
    )
    //HTML
    return (
        <div className='main'>
            <div className='container'>
                <div className='search'>
                    <input type="search" placeholder="Search the movies....." value={search} onChange={changeTheSearch} className='input' />
                </div>
                <div className='card-section'>
                {movies.length==0? "Loading...":movies.map((data,index)=>{
                    return(
                        <Card key={index} value= {data} />
                    )
                })}
                </div>
            </div>

        </div>
    )
}
